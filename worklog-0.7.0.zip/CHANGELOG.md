# WorkLog : historique des versions

## 0.7.0
**Graphiques**
- Un seul point par jour (avant : un point par série, d'où les traits verticaux quand on fait plusieurs séries le même jour).
- Trois onglets pour la musculation : « Force estimée » (par défaut), « Charge max » et « Volume ».
- Force estimée : la charge que tu pourrais soulever une fois (1RM), calculée pour chaque série avec la formule d'Epley, poids × (1 + répétitions ÷ 30) ; le point du jour est ta meilleure série. Une explication du calcul s'affiche sous le graphique, avec l'exemple de la série retenue.
- Charge max : la charge la plus lourde du jour, avec le nombre de répétitions faites à cette charge au-dessus du point.
- Volume : le total du jour (poids × répétitions de toutes les séries), c'est-à-dire l'ancien graphique.
- Cardio et étirements aussi par jour : durée totale, meilleure vitesse, plus longue tenue, niveau le plus haut, tours du jour.
- Graphique plus lisible : points plus gros, zone colorée sous la courbe, date complète du point sélectionné.

**Poids du corps**
- Nouveau réglage « Poids du corps » (menu › Réglages).
- Case « PDC » sur chaque série (« Poids du corps » dans la fenêtre de modification et dans les séances types). Cochée, le champ du poids devient le lest, avec un bouton + / − devant : + pour ajouter du lest, − pour retirer du poids (exercice assisté). Taper « - » ou « + » au début du champ règle aussi le bouton. Le total soulevé s'affiche à côté de la case.
- La série enregistre le poids total (poids du corps + lest) : graphiques et totaux restent justes même si ton poids change ensuite. Affichage : « PDC + 10 kg × 8 », « PDC − 20 kg × 8 ».
- Une nouvelle série reprend le mode PDC de la dernière série de l'exercice. Les séries prévues des séances types peuvent aussi être au poids du corps.

**Séries**
- « Dernières séances » : un bouton « dupliquer » à côté de chaque série la recopie dans « Nouvelle série » (toucher la série la modifie toujours).
- Les boutons dupliquer et retirer d'une série sont sur la même ligne que les champs, calés à droite (saisie, séances types).
- Le champ « Date et heure » ne dépasse plus de la fenêtre « Modifier la série » sur iPhone.

**Programmer des séances**
- « Programmer » une séance type (menu « … » d'une séance, ou bouton sur la page de la séance) : à une date précise, ou en répétition chaque semaine ou toutes les 2, 3 ou 4 semaines, les jours choisis, avec une date de fin facultative.
- Dans le calendrier, « Prévoir une séance type » sur aujourd'hui ou un jour à venir. On peut maintenant aller dans les mois suivants : les jours programmés y sont entourés.
- Une séance répétée est ajoutée au jour même (ou quand tu ouvres ce jour à l'avance). La page de la séance type liste ses programmations, avec une croix pour en arrêter une.

**Supprimer une séance**
- Dans le calendrier, « Retirer le nom de cette séance » devient « Supprimer la séance » : le nom et les exercices prévus pas encore faits disparaissent, les séries déjà faites restent, et tu reviens à la page précédente (avec « Annuler »).
- Supprimer une séance type retire aussi du calendrier ses exercices prévus pas encore faits (aujourd'hui compris) et sa programmation. Les séries déjà faites restent.

**Bibliothèque et recherche**
- Favoris et Mes séances : tous les dossiers sont fermés à l'ouverture, comme dans la bibliothèque.
- Étoile « favori » sur chaque exercice quand on ajoute des exercices à une séance.
- Recherche : chaque mot est cherché séparément, en français et en anglais, avec une tolérance aux fautes de frappe (« hip trust » trouve « Hip thrust à la barre »). Les résultats qui contiennent tous les mots passent en premier.
- Pendant une recherche : filtres par type (Tout, Favoris, Musculation, Étirements) et par groupe musculaire, avec le nombre de résultats.
- Correction du plantage après avoir parcouru beaucoup d'exercices : les vignettes (gifs, photos, mannequins 3D) ne sont chargées qu'à l'écran et retirées de la mémoire dès qu'elles en sortent ; un groupe refermé libère son contenu.

**Export et import**
- L'export ne crée plus de fichier texte « WorkLog » en plus de la sauvegarde.
- Favoris : « Exporter les favoris » et « Importer » dans l'onglet Favoris.
- Mes séances : « Exporter des séances » (toutes, ou seulement celles cochées) et « Importer ».
- Un import ajoute ce qui manque, sans rien effacer ni créer de doublon (deux séries identiques faites la même minute restent bien deux séries).
- L'export complet (Historique) contient tout ce que tu as rempli : séries, favoris, séances, notes, séances types, dossiers, programmations et réglages (poids du corps, adresse du NAS ; jamais le mot de passe).

**Langue**
- Français ou anglais (menu › Réglages › Langue) : toute l'application, y compris les 1 861 noms d'exercices. Les noms français suivent les termes courants des salles (développé couché, rowing, tirage vertical, oiseau, soulevé de terre…). La recherche marche dans les deux langues.

**Synchronisation avec ton NAS**
- Nouvelle section dans Réglages : adresse de ton serveur PocketBase, e-mail, mot de passe. Synchronisation automatique à l'ouverture et quelques secondes après chaque modification, bouton « Synchroniser maintenant », « Remplacer par les données du NAS », « Se déconnecter ».
- L'app ne contacte que l'adresse saisie ; le jeton de connexion reste sur le téléphone, le mot de passe n'est pas enregistré. Si deux appareils ont changé en même temps, les données sont fusionnées.
- Guide d'installation pour Synology DS224+ (Container Manager + PocketBase, accès HTTPS par Tailscale ou proxy inversé) : `docs/synchronisation-nas.html`, et la collection à importer : `docs/pocketbase-worklog.json`.

**Strava**
- « Copier pour Strava » dans le détail d'un jour : un résumé texte (exercices et séries, séries identiques regroupées) à coller dans la description de l'activité enregistrée par ta montre.

**Fichiers**
- Nouveaux : `js/i18n.js` (textes anglais), `data/names-fr.json` (noms français des exercices), `docs/` (guide NAS et collection PocketBase).

## 0.6.2.3
- Ischio unilat assis : la jambe tendue ne se retourne plus (l'ischio reste derrière la cuisse). Par défaut, le genou suit maintenant la cuisse sans rotation de hanche, pour toutes les jambes.
- Piriforme : mains visibles (main gauche sur la cuisse gauche, main droite qui pousse le genou droit), plus de main qui se retourne entre deux positions. Angle de départ qui montre à la fois les mains et la zone étirée.
- Ischios allongé : les mains tiennent l'arrière de la cuisse sur la peau, sans y entrer.
- Les mains qui tiennent un membre sont posées exactement sur sa surface et le suivent pendant les transitions.
- Corrections relevées par les nouveaux contrôles : Piriforme avec torsion, Prière latérale, Cheville dynamique en fente, Pec élastique, Phoque, Hanche et adducteur unilat, Grand dorsal/triceps avec barre.

## 0.6.2.2
- Dépôt GitHub rangé en dossiers : `js/` (code), `css/` (styles), `data/` (exercices et schéma du corps), `models/` (mannequin 3D), `icons/` (icônes). À la racine : `index.html`, `sw.js`, `manifest.webmanifest`, `README.md`, `CHANGELOG.md`, `CREDITS.txt`.
- Mise à jour par simple dépôt du zip : GitHub le déballe, range les fichiers, retire ceux qui ne servent plus et publie le site.
- Ajout d'un `README.md` qui présente l'app et la façon de la mettre à jour.
- Aucun changement dans l'app elle-même.

## 0.6.2
- Mannequin 3D : le corps garde son volume aux articulations. Les fesses ne s'écrasent plus quand la hanche plie beaucoup (Ischio unilat assis, Piriforme…), et les épaules et les coudes se déforment mieux.
- Poignets naturels : la rotation de la main passe par l'avant-bras (et par l'épaule quand le bras est tendu) au lieu de vriller le poignet. Bras tendus et mains à plat dans « Piriforme avec torsion ».
- Les mains qui se déplacent ne tournent plus sur elles-mêmes pendant les transitions.
- Muscles ciblés plus visibles : couleurs plus marquées, zones du piriforme et du TFL agrandies, angle de vue de départ choisi pour montrer le muscle principal de chaque exercice.

## 0.6.1
- Le mannequin 3D des 26 exercices d'étirements et de mobilité est remplacé par un corps réaliste (modèle « Male base muscular anatomy », CC BY 4.0).
- Plus de sol ni d'ombre : on peut tourner autour du mannequin dans tous les sens, y compris par en dessous.
- Animations plus fluides (plus d'à-coups) et contrôle automatique pour que les membres ne passent plus les uns dans les autres.
- Nouveaux muscles colorés et nommés : psoas, piriforme, TFL, rhomboïdes, deltoïde postérieur, coiffe des rotateurs.
- « Grand dorsal/triceps avec barre » refait d'après la vidéo (départ à genoux, puis assis sur les talons, coudes sur la caisse).

## 0.6.0
- Nouveau : 26 exercices d'étirements et de mobilité « maison », en français, dans l'onglet Étirements de la bibliothèque.
- Chaque exercice est montré par un mannequin 3D animé en boucle, avec les muscles ciblés colorés sur le corps et le matériel (caisse, bâton, élastique, haltère). Sur la fiche, on fait tourner le mannequin au doigt.
- Ces exercices se notent à la durée uniquement (secondes par série), avec un graphique de durée. « Durée par côté » est rappelé pour les exercices d'un seul côté.
- Séances types : une durée prévue par série pour ces exercices.
- « Prière » et « Dos rond/dos creux » remplacent « Child's pose » et « Cat stretch » ; l'historique et les favoris suivent.

## 0.5.3
- Correction : glisser la carte « Séance du jour » vers la gauche sur l'accueil la retire bien, même si des séries sont déjà faites. Les séries restent dans le calendrier et l'historique.
- Relancer une séance « Aujourd'hui » fait réapparaître la carte.

## 0.5.2
- Les copies de page laissées par une animation interrompue sont effacées à chaque changement de page.
- Les pages ont un fond plein.
- Le numéro de version s'affiche en bas du menu.

## 0.5.1
- Nouveau : retirer la séance du jour en glissant sa carte sur l'accueil, ou avec le bouton « Retirer la séance prévue » dans le calendrier, avec « Annuler ».

## 0.5.0
- Calendrier : le détail du jour s'affiche sous le calendrier ; on change de jour sans changer de page.
- Création de séance : brouillon enregistré seulement avec « Valider ». Un message indique les informations manquantes, et une fenêtre propose d'enregistrer en quittant.
- Mes séances : bouton « Nouveau dossier ». Section « Sans dossier » repliable. Menu « … » sur chaque séance (Déplacer vers, Renommer, Dupliquer, Supprimer) et sur chaque dossier (Renommer, Supprimer sans effacer les séances). Glisser une séance vers un dossier.
- Groupes secondaires choisis dans une liste à cocher compacte.
- Vignettes animées seulement quand elles sont à l'écran. Toucher une vignette l'agrandit.
- Ajout d'exercices : toute la ligne sélectionne.
- Réorganisation au doigt plus fluide, sans sélection de texte, avec défilement automatique.
- Bandeau du haut qui réapparaît quand on remonte.
- Animations : la page arrive de la droite, la flèche la fait repartir à droite, la croix la fait descendre.
- Note plus petite, sur une ligne.

## 0.4.1
- Muscles du schéma et de la légende vérifiés image par image sur les 1 324 exercices ExerciseDB.

## 0.4.0
- Séances types rangées en dossiers, lancées « Aujourd'hui ».
- Refaire une ancienne séance avec les charges préremplies, ou l'enregistrer comme séance type.
- Ordre des exercices modifiable.
- Glisser vers la gauche pour supprimer un exercice ou une série. Toucher une série pour la modifier.
- « Annuler » après « Valider », qui ramène à la saisie.
- Barre de calcul + − × ÷ ( ) = au-dessus du clavier pour le poids.
- Fenêtre « Enregistrer ? » en quittant avec une série non validée.
- Dupliquer une ligne de série.
- Notes par exercice et par journée.
- Cardio : durée, distance, vitesse, niveau ou tours selon l'activité.
- Export d'une journée en fichier d'activité .tcx (Strava, Garmin).

## 0.3.1
- Recherche : bouton pour tout effacer, nom exact en premier, « pull up » = « pull-up » = « pullup ».

## 0.3.0
- Base fusionnée : ExerciseDB et free-exercise-db, sans doublons, 1 837 exercices, noms en anglais.
- Schéma du corps (face et dos) avec les muscles colorés, et gif agrandissable.
- Bibliothèque en onglets : Favoris, Musculation, Étirements.
- Bouton « Séances » sur l'accueil.

## 0.2.0
- Base d'exercices intégrée à l'app, avec des images nettes.
- Catégories de la tête aux pieds, avec sous-catégories.
- Graphique sur 2 semaines par défaut, puis 1, 3 et 6 mois.
- Retour en arrière qui garde la position.
- Nommer une séance. Nouvelle page « Séances ».

## 0.1.0
- Première version : bibliothèque d'exercices, saisie des séries, graphique, historique, calendrier, import et export.
